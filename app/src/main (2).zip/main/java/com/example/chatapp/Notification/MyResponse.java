package com.example.chatapp.Notification;

public class MyResponse {
    public int success;
}
