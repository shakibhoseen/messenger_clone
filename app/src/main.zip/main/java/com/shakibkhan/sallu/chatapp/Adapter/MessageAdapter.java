package com.shakibkhan.sallu.chatapp.Adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.shakibkhan.sallu.chatapp.Model.Chat;
import com.shakibkhan.sallu.chatapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    private static final int MSG_TYPE_LEFT = 0;
    private static final int MSG_TYPE_RIGHT = 1;
    private Context mcontext;
    private List<Chat> mchat;
    private String imgUrl;
    FirebaseUser firebaseUser;

    public MessageAdapter(Context mcontext, List<Chat> chats, String imgUrl) {

        this.mcontext = mcontext;
        this.mchat = chats;
        this.imgUrl = imgUrl;
    }

    @Override
    public int getItemViewType(int position) {
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser.getUid().equals(mchat.get(position).getSender())){
            return MSG_TYPE_RIGHT;
        }else
        return MSG_TYPE_LEFT ;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        if (i == MSG_TYPE_LEFT){
            View view = LayoutInflater.from(mcontext).inflate(R.layout.chat_item_left,viewGroup,false);
            return new MessageAdapter.ViewHolder(view);
        }else{
            View view = LayoutInflater.from(mcontext).inflate(R.layout.chat_item_right,viewGroup,false);
            return new MessageAdapter.ViewHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
          Chat chat= mchat.get(i);
          if (!chat.getMessage().equals("")){
              viewHolder.show_message.setText(chat.getMessage());
              viewHolder.show_message.setVisibility(View.VISIBLE);
          }
          if (chat.getImageUrl()!=null){
              viewHolder.show_imgMsg.setVisibility(View.VISIBLE);
              Picasso.with(mcontext).load(chat.getImageUrl()).into(viewHolder.show_imgMsg);

          }

          if(imgUrl.equals("default")){
              viewHolder.profile_image.setImageResource(R.mipmap.ic_launcher);
          }else Picasso.with(mcontext).load(imgUrl).into(viewHolder.profile_image);



          if(i == mchat.size()-1){
              if (chat.getIsseen()){
                  viewHolder.txt_seen.setText("seen");
              }else {
                  viewHolder.txt_seen.setText("Delivered");
              }
          }else {
              viewHolder.txt_seen.setVisibility(View.GONE);
          }
    }

    @Override
    public int getItemCount() {
        return mchat.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
         public TextView show_message;
         public TextView txt_seen;
         public ImageView profile_image;
         public ImageView show_imgMsg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            show_message= itemView.findViewById(R.id.show_message);
            profile_image = itemView.findViewById(R.id.profile_image);
            txt_seen = itemView.findViewById(R.id.txt_seen);
            show_imgMsg=itemView.findViewById(R.id.show_imgMsg);
        }
    }

}
