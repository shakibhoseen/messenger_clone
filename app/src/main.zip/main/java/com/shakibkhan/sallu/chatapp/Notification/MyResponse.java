package com.shakibkhan.sallu.chatapp.Notification;

public class MyResponse {
    public int success;
}
